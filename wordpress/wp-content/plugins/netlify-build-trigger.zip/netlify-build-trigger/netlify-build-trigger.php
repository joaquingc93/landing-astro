<?php
/**
 * Plugin Name: Netlify Build Trigger (RenovaLink)
 * Description: Dispara un build de Netlify cuando se publica o actualiza un servicio o proyecto.
 * Version: 1.0.0
 * Author: RenovaLink Dev Automation
 */

if (!defined('ABSPATH')) { exit; }

// URL del Build Hook de Netlify (proporcionada por el usuario)
if (!defined('RENOVALINK_NETLIFY_BUILD_HOOK')) {
    define('RENOVALINK_NETLIFY_BUILD_HOOK', 'https://api.netlify.com/build_hooks/68dc32c2462086a77888dafe');
}

// CPTs / post types a monitorear (incluye ahora 'page'). Se hace filtrable.
function rl_get_watched_post_types() {
    $default = [ 'proyectos', 'servicios', 'page' ];
    return apply_filters('renovalink_netlify_watched_post_types', $default);
}

// Tiempo mínimo entre builds (segundos) para evitar spam accidental
const RENOVALINK_BUILD_THROTTLE_SECONDS = 60; // 1 minuto

/**
 * Determina si se debe disparar el build
 */
function rl_should_trigger_netlify_build($post_id, $post, $update) {
    if (wp_is_post_autosave($post_id) || wp_is_post_revision($post_id)) {
        return false;
    }

    $watched = rl_get_watched_post_types();
    if (!in_array($post->post_type, $watched, true)) {
        return false;
    }

    // Solo cuando está publicado
    if ($post->post_status !== 'publish') {
        return false;
    }

    return true;
}

/**
 * Lógica principal para disparar el build hook de Netlify
 */
function rl_trigger_netlify_build($post_id, $post, $update) {
    if (!rl_should_trigger_netlify_build($post_id, $post, $update)) {
        return; // No cumple condiciones
    }

    // Throttle simple
    $last = get_option('rl_last_build_trigger_time');
    $now  = time();
    if ($last && ($now - (int)$last) < RENOVALINK_BUILD_THROTTLE_SECONDS) {
        return; // Demasiado pronto desde el último build
    }

    $body = [
        'trigger_title' => 'Content update: ' . $post->post_type . ' #' . $post_id,
        'source'        => 'wordpress-hook',
        'updated_slug'  => $post->post_name,
    ];

    $args = [
        'timeout'  => 8,
        'blocking' => false, // No esperar respuesta completa
        'body'     => $body,
    ];

    $response = wp_remote_post(RENOVALINK_NETLIFY_BUILD_HOOK, $args);

    update_option('rl_last_build_trigger_time', $now);

    if (is_wp_error($response)) {
        error_log('[Netlify Build Trigger] Error: ' . $response->get_error_message());
    } else {
        error_log('[Netlify Build Trigger] Build disparado para post ' . $post_id . ' (' . $post->post_type . ')');
    }
}
add_action('save_post', 'rl_trigger_netlify_build', 10, 3);

/**
 * Añade una notificación en el admin después de guardar
 */
function rl_admin_notices() {
    if (!current_user_can('edit_posts')) return;

    $last = get_option('rl_last_build_trigger_time');
    if (!$last) return;

    $seconds_since = time() - (int)$last;
    if ($seconds_since < 120) { // Mostrar durante 2 minutos
        echo '<div class="notice notice-success is-dismissible"><p>Se ha disparado un build en Netlify. (Hace ' . esc_html($seconds_since) . 's)</p></div>';
    }
}
add_action('admin_notices', 'rl_admin_notices');

/**
 * Página de ajustes simple (opcional futuro)
 */
function rl_netlify_trigger_admin_menu() {
    add_options_page(
        'Netlify Build Trigger',
        'Netlify Build Trigger',
        'manage_options',
        'rl-netlify-trigger',
        'rl_netlify_trigger_settings_page'
    );
}
add_action('admin_menu', 'rl_netlify_trigger_admin_menu');

function rl_netlify_trigger_settings_page() {
    if (!current_user_can('manage_options')) return;
    echo '<div class="wrap"><h1>Netlify Build Trigger</h1>';
    echo '<p>Hook actual: <code>' . esc_html(RENOVALINK_NETLIFY_BUILD_HOOK) . '</code></p>';
    echo '<p>Types monitoreados (filtrables vía hook <code>renovalink_netlify_watched_post_types</code>): <code>' . implode(', ', rl_get_watched_post_types()) . '</code></p>';
    echo '<p>Throttle: ' . RENOVALINK_BUILD_THROTTLE_SECONDS . ' segundos.</p>';
    echo '<p>Este plugin dispara builds automáticamente al publicar/actualizar servicios o proyectos.</p>';
    echo '</div>';
}
